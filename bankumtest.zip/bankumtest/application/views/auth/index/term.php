<br>
    <br>
        <br>
    <br>
<div class="container">

    <div class="row">
    
        <div class="col-md-8 ml-auto mr-auto">
        
            <div class="card">
            
                <div class="text-center">
                
                    <h5 class="text-primary mt-3 mb-3"><b>User Conditions</b></h5>
                
                </div>

                <div class="text-justify">
                
                    <div class="container">
                    
                        <p><b>Welcome to Bankumtest</b></p>
                        <p class="small">These term of use govern the use of Bankumtest and provide information about Bankumtest service which will be described bellow. While you are using Bankumtest service, you are agree with these terms and conditions.</p>

                        <p><b>Important notes</b></p>
                        <p><b>Please read this document carefully</b></p>
                        <p class="small">This document contains the terms and conditions of
                            our relationship
                            with you. These terms and conditions apply to any
                            products and all services including the electronic
                            publication services that we agree to provide to you
                            from time to time. These terms and conditions apply
                            as a complement of other documents, including the
                            terms of the products and the publication charges sheet,
                            but these terms do not apply to facilities, products or
                            services that we currently provide to you as far as
                            the facilities, products or services are subject to
                            separate terms and conditions.</p>

                        <p><b>Authorization</b></p>
                        <p class="small">You shall authorize us to carry out the
                        instructions from you or any authorized party
                        (including any instruction which we believe has
                        been given by you or an authorized party). You
                        shall acknowledge that for electronic publication
                        services, we may to publish your article content to pubic.</p>
                    
                    </div>
                
                </div>
            
            </div>
        
        </div>
    
    </div>

</div>

<script type="text/javascript" src="<?= base_url();?>assets/js/jquery.js"></script>

<script>

    $(function(){
        $('body').on('contextmenu', function(e){
            return false;
        })
    })

</script>